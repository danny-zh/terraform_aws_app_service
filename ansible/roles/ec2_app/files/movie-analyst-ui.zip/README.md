# movie-analyst-ui


You will need to create a separate repository for this component of the movie analyst application to proceed with challenge #3 and #4



## Attributions
Application developed based on this post https://scotch.io/tutorials/building-and-securing-a-modern-backend-api